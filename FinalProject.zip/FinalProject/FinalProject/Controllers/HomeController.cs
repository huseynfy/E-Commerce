﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProject.DAL;
using FinalProject.Models;
using FinalProject.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace FinalProject.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _db;
        public HomeController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            ViewBag.CartCount = _db.Carts.Count();
            HomeVM home = new HomeVM
            {
                Sliders = _db.Sliders,
                SliderTexts = _db.SliderTexts.First(s => s.Id == 1),
                Products =_db.Products.Select(p=>new Product
                {
                    Id = p.Id,
                    Name = p.Name,
                    Price = p.Price,
                    Image = p.Image,
                    Category = p.Category,
                    Brand=p.Brand
                }),
                PromotedProducts=_db.PromotedProducts.First(p=>p.Id==1),
                Carts=_db.Carts
            };
            return View(home);
        }
    }
}