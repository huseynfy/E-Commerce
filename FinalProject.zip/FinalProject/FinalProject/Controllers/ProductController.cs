﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProject.DAL;
using FinalProject.Models;
using FinalProject.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace FinalProject.Controllers
{
    public class ProductController : Controller
    {
        private readonly AppDbContext _db;
        public ProductController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index(int? page)
        {
            ViewBag.CartCount = _db.Carts.Count();
            double proprice = _db.Carts.Sum(c => c.ProPrice);
            ViewBag.PriceCart = proprice;

            ViewBag.PageCount = Math.Ceiling((decimal)_db.Products.Count() / 9);
            if (page==null)
            {
                ViewBag.Page = 0;
                HomeVM home = new HomeVM
                {
                    Products = _db.Products.Select(p => new Product
                    {
                        Id = p.Id,
                        Name = p.Name,
                        Price = p.Price,
                        Image = p.Image,
                        Category = p.Category,
                        Brand = p.Brand
                    }).Take(9),
                    Brands = _db.Brands,
                    Categories = _db.Categories,
                    Carts = _db.Carts,
                    Contacts = _db.Contacts.First(c => c.Id == 1)
                };
                return View(home);
            }
            ViewBag.Page = page;
            HomeVM home1 = new HomeVM
            {
                Products = _db.Products.Select(p => new Product
                {
                    Id = p.Id,
                    Name = p.Name,
                    Price = p.Price,
                    Image = p.Image,
                    Category = p.Category,
                    Brand = p.Brand
                }).Skip(9*(int)page).Take(9),
                Brands = _db.Brands,
                Categories = _db.Categories,
                Carts = _db.Carts,
                Contacts = _db.Contacts.First(c => c.Id == 1)
            };
            return View(home1);
           
        }
        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Index(string search)
        {
            ViewBag.CartCount = _db.Carts.Count();
            double proprice = _db.Carts.Sum(c => c.ProPrice);
            ViewBag.PriceCart = proprice;

            ViewBag.Page = 0;
            ViewBag.PageCount = Math.Ceiling((decimal)_db.Products.Count() / 10);
            if (search == null)
            {
                ModelState.AddModelError("", "Please enter something!");
                HomeVM home1 = new HomeVM
                {
                    Products = _db.Products.Select(p => new Product
                    {
                        Id = p.Id,
                        Name = p.Name,
                        Price = p.Price,
                        Image = p.Image,
                        Category = p.Category,
                        Brand = p.Brand
                    }).Take(9),
                    Brands = _db.Brands,
                    Categories = _db.Categories,
                    Carts = _db.Carts,
                    Contacts = _db.Contacts.First(c => c.Id == 1)
                };
                return View(home1);
            }
            HomeVM home = new HomeVM
            {
                Products = _db.Products.Where(p => p.Name.Contains(search) || p.Brand.Name.Contains(search)
                ||p.Category.Name.Contains(search)).Take(9)
                .Select(p => new Product
                {
                    Id = p.Id,
                    Name = p.Name,
                    Price = p.Price,
                    Image = p.Image,
                    Category = p.Category,
                    Brand = p.Brand
                }).Take(9),
                Brands = _db.Brands,
                Categories = _db.Categories,
                Carts = _db.Carts,
                Contacts = _db.Contacts.First(c => c.Id == 1)
            };
            return View(home);
        }

        public async Task<IActionResult> Detail(int id,int imgid)
        {
            ViewBag.CartCount = _db.Carts.Count();
            double proprice = _db.Carts.Sum(c => c.ProPrice);
            ViewBag.PriceCart = proprice;

            Product pro = await _db.Products.FindAsync(id);
            Image image = await _db.Images.FindAsync(imgid);
            Brand brand = await _db.Brands.FindAsync(pro.BrandId);
            HomeVM home = new HomeVM
            {
                Product = pro,
                Products = _db.Products.Select(p => new Product
                {
                    Id = p.Id,
                    Name = p.Name,
                    Price = p.Price,
                    Image = p.Image,
                    Category = p.Category,
                    Brand = brand
                }),
                Brands = _db.Brands,
                Categories = _db.Categories,
                Image=image,
                ProductReviews=_db.ProductReviews,
                Carts=_db.Carts,
                Contacts = _db.Contacts.First(c => c.Id == 1)
            };
            return View(home);
        }
       
    }
}