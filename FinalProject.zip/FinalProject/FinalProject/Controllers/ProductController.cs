﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProject.DAL;
using FinalProject.Models;
using FinalProject.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace FinalProject.Controllers
{
    public class ProductController : Controller
    {
        private readonly AppDbContext _db;
        public ProductController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            ViewBag.CartCount = _db.Carts.Count();
            HomeVM home = new HomeVM
            {
                Products = _db.Products.Select(p => new Product
                {
                    Id = p.Id,
                    Name = p.Name,
                    Price = p.Price,
                    Image = p.Image,
                    Category = p.Category,
                    Brand = p.Brand
                }),
                Brands=_db.Brands,
                Categories=_db.Categories,
                Carts=_db.Carts
            };
            return View(home);
        }
        public async Task<IActionResult> Detail(int id,int imgid)
        {
            Product pro = await _db.Products.FindAsync(id);
            Image image = await _db.Images.FindAsync(imgid);
            Brand brand = await _db.Brands.FindAsync(pro.BrandId);
            HomeVM home = new HomeVM
            {
                Product = pro,
                Products = _db.Products.Select(p => new Product
                {
                    Id = p.Id,
                    Name = p.Name,
                    Price = p.Price,
                    Image = p.Image,
                    Category = p.Category,
                    Brand = brand
                }),
                Brands = _db.Brands,
                Categories = _db.Categories,
                Image=image,
                ProductReviews=_db.ProductReviews,
                Carts=_db.Carts
            };
            return View(home);
        }
     
    }
}