﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProject.DAL;
using FinalProject.Models;
using FinalProject.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace FinalProject.Controllers
{
    public class ProductController : Controller
    {
        private readonly AppDbContext _db;
        public ProductController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            HomeVM home = new HomeVM
            {
                Products = _db.Products.Select(p => new Product
                {
                    Id = p.Id,
                    Name = p.Name,
                    Price = p.Price,
                    Image = p.Image,
                    Category = p.Category,
                    Brand = p.Brand
                }),
                Contacts = _db.Contacts.First(c => c.Id == 1),
                Brands=_db.Brands,
                Categories=_db.Categories
            };
            return View(home);
        }
        public async Task<IActionResult> Detail(int id,int imgid)
        {
            Product pro = await _db.Products.FindAsync(id);
            Image image = await _db.Images.FindAsync(imgid);
            HomeVM home = new HomeVM
            {
                Product = pro,
                Products = _db.Products.Select(p => new Product
                {
                    Id = p.Id,
                    Name = p.Name,
                    Price = p.Price,
                    Image = p.Image,
                    Category = p.Category,
                    Brand = p.Brand
                }),
                Contacts = _db.Contacts.First(c => c.Id == 1),
                Brands = _db.Brands,
                Categories = _db.Categories,
                Image=image,
                ProductText=_db.ProductTexts.First(p=>p.Id==1),
                ProductReviews=_db.ProductReviews
            };
            return View(home);
        }
    }
}