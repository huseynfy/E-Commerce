﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProject.DAL;
using FinalProject.ViewModels;
using Microsoft.AspNetCore.Mvc;
using FinalProject.Models;

namespace FinalProject.Controllers
{
    public class ContactController : Controller
    {
        private readonly AppDbContext _db;
        public ContactController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            ViewBag.CartCount = _db.Carts.Count();
            double proprice = _db.Carts.Sum(c => c.ProPrice);
            ViewBag.PriceCart = proprice;
            HomeVM home = new HomeVM()
            {
                Carts = _db.Carts,
                Contacts = _db.Contacts.First(c => c.Id == 1)
            };
            return View(home);
        }
        [HttpPost,ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(ContactUs contact)
        {
            if (!ModelState.IsValid)
            {
                HomeVM home = new HomeVM()
                {
                    Carts = _db.Carts,
                    Contacts = _db.Contacts.First(c => c.Id == 1)
                };
                return View(home);
            }
            await _db.ContactUS.AddAsync(contact);
            await _db.SaveChangesAsync();
            ViewBag.SuccessMsg = "Thanks , we will try to reach you as soon as possible!";
            return RedirectToAction("Index");
        }
    }
}