﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProject.DAL;
using FinalProject.Models;
using FinalProject.ViewModels;
using Microsoft.AspNetCore.Mvc;
using WebMatrix.WebData;

namespace FinalProject.Controllers
{
    public class CartController : Controller
    {
        private readonly AppDbContext _db;
        public CartController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            HomeVM home = new HomeVM
            {
                Contacts = _db.Contacts.First(c => c.Id == 1),
                Carts=_db.Carts
            };
            return View(home);
        }
        public async Task<IActionResult> AddToCart(int id)
        {
            var user = User.Identity.Name;
            Product pro =await _db.Products.FindAsync(id);
            Cart cartpro = new Cart()
            {
                Name = pro.Name,
                Price = pro.Price,
                Count = 1,
                UserName = user,
                Image = pro.Image.Image1,
                ProId=pro.Id
            };
            Cart existpro = await _db.Carts.FindAsync(cartpro.ProId);
            existpro.Count++;
            await _db.Carts.AddAsync(cartpro);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}