﻿using FinalProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProject.ViewModels
{
    public class HomeVM
    {
        public IEnumerable<Slider> Sliders { get; set; }
        public SliderText SliderTexts { get; set; }
        public IEnumerable<Product> Products { get; set; }
        public Contact Contacts { get; set; }
        public PromotedProduct PromotedProducts { get; set; }
        public IEnumerable<Brand> Brands { get; set; }
        public IEnumerable<Category> Categories { get; set; }
        public IEnumerable<Blog> Blogs { get; set; }
        public Product Product { get; set; }
        public Image Image{ get; set; }
        public ProductText ProductText { get; set; }
        public IEnumerable<ProductReview> ProductReviews { get; set; }
    }
}
