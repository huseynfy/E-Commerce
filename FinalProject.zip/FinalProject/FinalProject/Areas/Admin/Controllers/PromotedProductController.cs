﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProject.DAL;
using FinalProject.Extentions;
using FinalProject.Models;
using FrontToBack.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;

namespace FinalProject.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class PromotedProductController : Controller
    {
        private readonly AppDbContext _db;
        private readonly IWebHostEnvironment _env;
        public PromotedProductController(AppDbContext db,IWebHostEnvironment env)
        {
            _db = db;
            _env = env;
        }
        public IActionResult Index()
        {
            return View(_db.PromotedProducts.First(p=>p.Id==1));
        }
        public IActionResult Update()
        {
            return View(_db.PromotedProducts.First(p => p.Id == 1));
        }
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(PromotedProduct prom)
        {
            if (!prom.PhotoBig.IsImage())
            {
                ModelState.AddModelError("PhotoBig", "This is not an image");
                return View();
            }
            if (!prom.PhotoMedium.IsImage())
            {
                ModelState.AddModelError("PhotoMedium", "This is not an image");
                return View();
            }
            if (!prom.PhotoSmall1.IsImage())
            {
                ModelState.AddModelError("PhotoSmall1", "This is not an image");
                return View();
            }
            if (!prom.PhotoSmall2.IsImage())
            {
                ModelState.AddModelError("PhotoSmall2", "This is not an image");
                return View();
            }
            if (prom.PhotoBig.LessThan(2))
            {
                ModelState.AddModelError("PhotoBig", "Image must be less than 2 mb");
                return View();
            }
            if (prom.PhotoMedium.LessThan(2))
            {
                ModelState.AddModelError("PhotoMedium", "Image must be less than 2 mb");
                return View();
            }
            if (prom.PhotoSmall1.LessThan(2))
            {
                ModelState.AddModelError("PhotoSmall1", "Image must be less than 2 mb");
                return View();
            }
            if (prom.PhotoSmall2.LessThan(2))
            {
                ModelState.AddModelError("PhotoSmall2", "Image must be less than 2 mb");
                return View();
            }
            PromotedProduct imagepro = _db.PromotedProducts.First(p => p.Id == 1);
            FileHelper.DeleteImg(_env.WebRootPath, "img/", imagepro.ImageBig);
            FileHelper.DeleteImg(_env.WebRootPath, "img/", imagepro.ImageMedium);
            FileHelper.DeleteImg(_env.WebRootPath, "img/", imagepro.ImageSmall1);
            FileHelper.DeleteImg(_env.WebRootPath, "img/", imagepro.ImageSmall2);
            string filename1 = await prom.PhotoBig.SavePhoto(_env.WebRootPath, "img/");
            imagepro.ImageBig = filename1;
            string filename2 = await prom.PhotoMedium.SavePhoto(_env.WebRootPath, "img/");
            imagepro.ImageMedium = filename2;
            string filename3 = await prom.PhotoSmall1.SavePhoto(_env.WebRootPath, "img/");
            imagepro.ImageSmall1 = filename3;
            string filename4 = await prom.PhotoSmall2.SavePhoto(_env.WebRootPath, "img/");
            imagepro.ImageSmall2 = filename4;
            await _db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
    }
}