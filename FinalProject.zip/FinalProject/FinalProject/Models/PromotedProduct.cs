﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProject.Models
{
    public class PromotedProduct
    {
        public int Id { get; set; }
        public string ImageBig { get; set; }
        public string ImageSmall1 { get; set; }
        public string ImageSmall2 { get; set; }
        public string ImageMedium { get; set; }
    }
}
